class operatorLogika {
    public static void main(String[] args) {
        // Diberikan nilai A, B, C, K, L, dan M
        int A = 3; 
        int B = 6;
        int C = 2;
        int K = 5;
        int L = 4;
        int M = 3;

        boolean ekspresiA = (4 + 2 > A) && (B - 2 > 3 + 2) || (B + 2 <= 6 + 2);
        System.out.println("Hasil ekspresi a: " + ekspresiA);

        boolean ekspresiB = (K + 5 < M) || ((C * M < L) && (2 * M - L > 0));
        System.out.println("Hasil ekspresi b: " + ekspresiB);

        boolean ekspresiC = (L + 5 < M) || ((C * K < L) && (2 * K - L > 0));
        System.out.println("Hasil ekspresi c: " + ekspresiC);

        boolean ekspresiD = (A * 4 <= 3 * M + B);
        System.out.println("Hasil ekspresi d: " + ekspresiD);

        boolean ekspresiE = (K + 10 > A) && (L - 2 > 4 * C);
        System.out.println("Hasil ekspresi e: " + ekspresiE);
    }
}	