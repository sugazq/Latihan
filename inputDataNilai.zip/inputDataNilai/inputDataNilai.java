import java.util.Scanner;
public class inputDataNilai {
     public static void main(String[] args) {
    	
        Scanner input = new Scanner(System.in);
    	
        // Getting float input
        System.out.print("Nama           : ");
        String Name = input.nextLine();
    	
        // Getting double input
        System.out.print("NIM            : ");
        int Nim = input.nextInt();
    	
        System.out.print("Nilai Tugas    : ");
        int Tugas = input.nextInt();

        System.out.print("Nilai UTS      : ");
        int UTS = input.nextInt();

        System.out.print("Nilai UAS      : ");
        int UAS = input.nextInt();

        double Akhir = Tugas*30/100 + UTS*30/100 + UAS*40/100;
        
        System.out.println("===== Data Nilai Mahasiswa =====");
        System.out.println("Nama        : " + Name);
        System.out.println("NIM         : " + Nim);
        System.out.println("Tugas       : " + Tugas);
        System.out.println("UTS         : " + UTS);
        System.out.println("UAS         : " + UAS);
        System.out.println("Nilai Akhir : " + Akhir);
        System.out.println("================================");
    }
}


